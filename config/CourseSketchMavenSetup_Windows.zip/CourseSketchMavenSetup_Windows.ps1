Write-Host "This will download maven, protobuf, and protoc into the correct directories and add all environment variables needed for CourseSketch."
Write-Host "Press any key to start..."
$HOST.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL

$drive = Read-Host "Enter drive letter that you want to install files to (only the letter, nothing else)"

Write-Host "Creating file directories."
New-Item -ItemType directory -Path $drive:\maven-3.2.3 | OUT-NULL
New-Item -ItemType directory -Path $drive:\protobuf-2.5.0 | OUT-NULL
New-Item -ItemType directory -Path $drive:\protoc-2.5.0-win | OUT-NULL

Write-Host "Downloading Maven."
$url = "http://mirror.reverse.net/pub/apache/maven/maven-3/3.2.3/binaries/apache-maven-3.2.3-bin.zip"
$path = $drive + ":\maven-3.2.3\maven.zip"
$username = ""
$password = ""

$WebClient = New-Object System.Net.WebClient
$WebClient.Credentials = New-Object System.Net.Networkcredential($username,$password)
$WebClient.DownloadFile($url,$path)

Write-Host "Downloading protobuf."
$url = "https://protobuf.googlecode.com/svn/rc/protobuf-2.5.0.zip"
$path = $drive + ":\protobuf-2.5.0\protobuf.zip"
$WebClient.DownloadFile($url,$path)

Write-Host "Downloading protoc."
$url = "https://protobuf.googlecode.com/svn/rc/protoc-2.5.0-win32.zip"
$path = $drive + ":\protoc-2.5.0-win\protoc.zip"
$WebClient.DownloadFile($url,$path)

Write-Host "Unzippinng Maven."
cd $drive:\maven-3.2.3
$shell_app = new-object -com shell.application
$filename = "maven.zip"
$zip_file = $shell_app.namespace((Get-Location).Path + "\$filename")
$destination = $shell_app.namespace((Get-Location).Path)
$destination.Copyhere($zip_file.items())

Write-Host "Cleaning up Maven directory."
Remove-Item $drive:\maven-3.2.3\maven.zip
Move-Item $drive:\maven-3.2.3\apache-maven-3.2.3\* $drive:\maven-3.2.3
Remove-Item $drive:\maven-3.2.3\apache-maven-3.2.3

Write-Host "Unzippinng protobuf."
cd $drive:\protobuf-2.5.0
$shell_app = new-object -com shell.application
$filename = "protobuf.zip"
$zip_file = $shell_app.namespace((Get-Location).Path + "\$filename")
$destination = $shell_app.namespace((Get-Location).Path)
$destination.Copyhere($zip_file.items())

Write-Host "Cleaning up protobuf directory."
Remove-Item $drive:\protobuf-2.5.0\protobuf.zip
Move-Item $drive:\protobuf-2.5.0\protobuf-2.5.0\* $drive:\protobuf-2.5.0
Remove-Item $drive:\protobuf-2.5.0\protobuf-2.5.0

Write-Host "Unzippinng protoc."
cd $drive:\protoc-2.5.0-win
$shell_app = new-object -com shell.application
$filename = "protoc.zip"
$zip_file = $shell_app.namespace((Get-Location).Path + "\$filename")
$destination = $shell_app.namespace((Get-Location).Path)
$destination.Copyhere($zip_file.items())

Write-Host "Cleaning up protoc directory."
Remove-Item $drive:\protoc-2.5.0-win\protoc.zip


Write-Host "Adding directories to Environmental Path variable."
$oldPath=(Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment" -Name PATH).Path
$newPath=$oldPath+ ";$drive" + ":\maven-3.2.3\bin;" + $drive + ":\protobuf-2.5.0;" + $drive + ":\protoc-2.5.0-win"
Set-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment" -Name PATH -Value $newPath

Write-Host "Creating protoc variable for protofile pom reasons." | OUT-NULL
New-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment" -Name protoc -Value $drive+":\protoc-2.5.0-win\protoc.exe"

if  ( -not (Test-Path Env:\JAVA_HOME) )  {
Write-Host "Please add the system environment variable 'JAVA_HOME' with the value corresponding to the value of your jdk folder, for example 'C:\Program Files\Java\jdk.1.8.0_20'"
Write-Host "This can be done by right clicking computer, hitting properties, advanced system properties, environment variables, and adding new to system variables."
}

Write-Host "Restarting explorer so it recognizes our new environmental variables."
Stop-Process -processname explorer #Required to make Windows recognize the new path variables that were created through Registry Key edits above

Write-Host "Please restart GitHub if you have any instances open as the Git Shell loads environmental variables when GitHub opens. Press any key to exit."
$HOST.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL