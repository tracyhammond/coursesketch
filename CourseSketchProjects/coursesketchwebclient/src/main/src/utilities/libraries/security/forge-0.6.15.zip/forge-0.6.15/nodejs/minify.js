({
    paths: {
        forge: '../js'
    },
    name: '../js/forge',
    out: '../js/forge.min.js',
    preserveLicenseComments: false
})
